
let arr = ['Javascript', 'React', 'Python'];

// nombre d'éléments
arr.length; // --> 3

// indexOf() | includes() fonctionnent comment avec les chaînes de caractères

// pop() enlève le dernier élément
arr.pop();  // ['Javascript', 'React'];

// push() ajoute un ou des éléments à la fin
arr.push('Angular', 'Vue');  // --> ['Javascript', 'React', 'Angular', 'Vue']

// shift() enlève le premier élément
arr.shift();  // -->  ['React', 'Angular', 'Vue']

// unshift() ajoute un ou des éléments au début
arr.unshift('CSS', 'HTML');  // --> ['CSS', 'HTML', 'React', 'Angular', 'Vue']

// spread operator : ...
let arr1 = [1, 2, 3];
let arr2 = [4, 5, 6];
let newArr = [...arr1, ...arr2];  // [1, 2, 3, 4, 5, 6]


// découper une partie d'un tableau : slice()
// NE CHANGE PAS LE TABLEAU D'ORIGINE

let animals = ['cat', 'duck', 'dog', 'ant']

animals.slice(0, 2);  // --> ['cat', 'duck']
animals.slice(2);  // -->  ['dog', 'ant']

animals.slice(-1); // --> ['ant']


// splice() permet d'ajouter, enlever ou modifier des éléments d'un tableau
// CHANGE LE TABLEAU D'ORIGINE
// 1er paramètre : l'index où effectuer le changement
// 2ème paramètre : le nombre d'éléments à supprimer
// 3ème paramètre : le ou les éléments à ajouter

// si on vu juste ajouter des éléments, il faut préciser 0 en 2ème paramètre 

let fruits = ['🍌', '🍎', '🍍', '🥝', '🍓'];

fruits.splice(2, 2); // -->  ['🍌', '🍎', '🍓'];
fruits.splice(1, 0, '🍒');  // -->  ['🍌', '🍒', '🍎', '🍓'];


// join() transforme un tableau en chaîne de caractères

['JavaScript', 'is', 'cool'].join('-'); 'JavaScript-is-cool'

['JavaScript', 'is', 'cool'].join(' '); 'JavaScript is cool'

