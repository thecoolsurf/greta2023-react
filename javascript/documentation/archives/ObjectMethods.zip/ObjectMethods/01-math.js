

// ***  Méthodes de l'objet Math  *** //

// la majeure partie des méthodes ou propriétés s'utilisent directement depuis l'objet Math 

Math.PI;  // --> 3.141592653589793

// Math nous permet de réaliser des opérations mathématiques
Math.cos();
Math.sin();

// Math.round() arrondit au chiffre le plus proche
Math.round(10.3);  // --> 10
Math.round(10.8);  // --> 11
Math.round(10.5);  // --> 11


// Math.floor() arrondit au chiffre au-dessous
Math.floor(10.8);  // --> 10

// Math.ceil() arrondit au chiffre au-dessus 
Math.ceil(10.2); // --> 11

// Math.trunc() supprime les décimales
Math.trunc(12.58);  // --> 12


// Générer un nombre aléatoire

Math.random() // génère un nombre entre 0 inclus et 1 exclu

Math.random() * 10 // entre 0 inclus et 10 exclu

// choisir un intervalle
// Math.floor(Math.random() * (max - min + 1) + min);


Math.floor(Math.random() * (30 - 15 + 1) + 15); // entre 15 inclus et 30 exclu



// trouver une valeur minimale
Math.min(10, 50, 4, 8, 45);  // --> 4

// trouver une valeur maximale
Math.max(10, 50, 4, 8, 45);  // --> 50








