
// enlever ce qui est après un nombre décimal
Number.parseFloat('12.4px');  // --> 12.4

// enlever les chiffres après la virgule
Number.parseInt('12.4px');   // --> 12
Number.parseInt('12.4');   // --> 12


// choisir le nombre de chiffres après la virgule
12.45977.toFixed(2); // -->  12.45
12.45977.toFixed(1); // -->  12.4


// *** transformer une chaîne de caractères en number *** //
Number('4');
+'4';
'4' * 1;
Number.parseInt('4');
Number.parseFloat('4');
