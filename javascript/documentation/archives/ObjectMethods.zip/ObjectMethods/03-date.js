// l'objet Date permet de manipuler la date présente dans le système de l'utilisateur en

let todayStr = Date();
// --> 'Tue Nov 14 2023 10:25:57 GMT+0100 (heure normale d’Europe centrale)'
// type string

let todayObj = new Date();
// --> Tue Nov 14 2023 10:26:54 GMT+0100 (heure normale d’Europe centrale)
// type date

// on peut alors utiliser les méthodes de l'objet Date
todayObj.getDay();  // --> 2
todayObj.getMonth();  // --> 10
todayObj.getFullYear();  // --> 2023


todayObj.toLocaleDateString() // '14/11/2023'

// on peut créer un objet à passer en paramètre
let options = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
}

todayObj.toLocaleDateString('fr', options);
// --> mardi 14 novembre 2023

todayObj.toLocaleDateString('fr', {month: 'long'})
// --> novembre