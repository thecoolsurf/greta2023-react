


const names = ['Hubert', 'Jekeel', 'Nabil'];

// *** every() *** //

// si tous les éléments du tableau remplissent la condition
// la méthode every() renvoie true
names.every(item => item.includes('e'));  //  --> false


// *** some() *** //

// si au moins un des éléments du tableau remplit la condition
// la méthode some() renvoie true
names.some(item => item.includes('e'));  //  --> true


// *** sort() *** //

[1, 8, 2, 4, 3].sort();  // -->   [1, 2, 3, 4, 8]

[100, 4000, 500, 20000].sort();  // --> ⚠️  [100, 20000, 4000, 500]

[100, 4000, 500, 20000].sort((a,b) => a - b);  // --> [100, 500, 4000, 20000]

[100, 4000, 500, 20000].sort((a,b) => b - a);  // --> [20000, 4000, 500, 100]


['Vadim', 'Naïma', 'Hung'].sort();   // -->  ['Hung', 'Naïma', 'Vadim']

['vadim', 'NAIMA', 'hung'].sort();   // -->  ⚠️  ['NAIMA', 'hung', 'vadim']

['vadim', 'NAIMA', 'hung'].sort( (a, b) => a.localeCompare(b)); // -->  ['hung', 'NAIMA', 'vadim']

['vadim', 'NAIMA', 'hung'].sort( (a, b) => b.localeCompare(a)); // --> ['vadim', 'NAIMA', 'hung']


// reduce()