

let names = ['Soumah', 'Noemie', 'Thomas'];

let upperNames = [];

for (let name of names) {
    upperNames.push(name.toUpperCase())
}

// *** map() *** //

// la méthode map() est une boucle qui va renvoyer un nouveau tableau avec chaque élément modifié selon les instructions données
// map() prend en paramètre une fonction callback
// le paramètre de cette fonction callback est généralement appelé item

names.map(item => item.toUpperCase())
// --> ['SOUMAH', 'NOEMIE', 'THOMAS']


// *** filter() *** //

// la méthode filter() est une boucle qui va renvoyer un nouveau tableau qui contiendra uniquement les éléments respectant la ou les conditions données en instruction

names.filter(item => item.includes('a'))
// --> ['Soumah', 'Thomas']


// *** chaîner les méthodes *** //

names.filter(item => item.includes('a'))  // on commence par filtrer
    .map(item => item.toUpperCase())      //  on met en majuscules

// --> ['SOUMAH', 'THOMAS']