
let str = 'myString';

// nombre de caractères

str.length;  // --> 8


// on peut itérer une chaîne de caractères comme un tableau

for (let letter of str) {
    console.log(letter);  // --> "m" - "y" - "S" ...
}

// chercher une chaîne de caractères dans une chaîne de caractères
'word'.includes('or');  // --> true
'word'.includes('x');  // --> false

// on peut donner un index à partir duquel commencer la recherche
'javascript'.includes('java', 4); // false


// chercher l'index d'une chaîne de caractères 
'freedom'.indexOf('e'); // --> 2

// on peut donner un index à partir duquel commencer la recherche
'freedom'.indexOf('d', 3); // --> 4 (le numéro de l'index)

// si la chaine de caractères n'est pas trouvée
'freedom'.indexOf('z'); // --> -1

// transformer en majuscules
'freedom'.toUpperCase();  // --> 'FREEDOM'

// transformer en minuscules
'FREEDOM'.toLowerCase();  // --> 'freedom'


// découper une chaîne de caractères

// slice(startIndex, endIndex)
'JavaScript is cool'.slice(4, 10);  // --> 'Script';

// si pas de deuxième index --> va jusqu'à la fin
'JavaScript is cool'.slice(4);  // --> 'Script is cool';


let javascript = 'JavaScript is cool';

let script = javascript.slice(4, 10);

// *** la chaîne de caractères de départ n'est pas modifiée *** //


// Extraire le nom placé avant le @ dans chaque adresse mail

let usermails = ['jon.doe@gmail.com', 'jane.birkin@hotmail.fr'];

const findUserName = email => email.slice(0, email.indexOf('@'));



// il est possible de chaîner les différentes méthodes

let upperMail = 'JON.DOE@GMAIL.COM';

upperMail.slice(0, upperMail.indexOf('@'))
        .toLowerCase();

// --> 'jon.doe'


// remplacer une partie de chaîne de caractères

let hardCode = 'coding is quite hard';

let easyCode = hardCode.replace('hard', 'easy');

// *** la chaîne de caractères de départ n'est pas modifiée *** //

let telNumb = '01-23-45-67-89';

telNumb.replace('-', ' '); // remplace que le premier tiret

telNumb.replaceAll('-', ' ');  // --> '01 23 45 67 89'


// transformer une chaîne de caractères en tableau
// le paramètre est un séparateur (il va couper entre chaque séparateur donné)

'01-23-45-67-89'.split('-'); // --> ['01', '23', '45', '67', '89']

'javascript'.split(''); // --> ['j', 'a', 'v', 'a', 's', 'c', 'r', 'i', 'p', 't']

'javascript is awesome'.split(' '); // --> ['javascript', 'is', 'awesome']

