

const fruits = ['🍌', '🍓', '🍍', '🥝', '🍒', '🍐'];

// boucles pour parcourir les élémengts d'un tableau


// boucle for

for (let i=0; i < fruits.length; i++) {  // i = i + 1
    console.log(fruits[i]);
}

// boucle for of (spécifique aux tableaux)

for (let fruit of fruits) {
    console.log(fruit)
}


// break met fin à une fonction


/*

- CONSIGNE 1 :
    - boucler le tableau 
    - afficher chacun des éléments du tableau dans la console
    - arrêter la boucle dès que l'élément '🥝' a été affiché

- CONSIGNE 2 :
    - mêmes consignes
    - si l'élément '🥝' n'est pas trouvé dans le tableau :
        afficher un seul message A LA FIN de la boucle : 'Kiwi non trouvé'

*/

console.log('-- EXERCICE --');


// *** VERSION 1 *** //

let kiwiFound = false;

for (let fruit of fruits) {
    console.log(fruit);

    if (fruit === '🥝') {
        kiwiFound = true;
        break;
        console.log('instruction ignorée')
    }
}

if (!kiwiFound) {  // kiwiFound === false
    console.log('Kiwi non trouvé');
}

// *** VERSION 2 *** //

for (let fruit of fruits) {
    console.log(fruit);

    if (fruit === '🥝') {
        break;
    }
    else if (fruit === fruits[fruits.length-1]) { // est-ce que le fruit est le dernier du tableau
        console.log('Kiwi non trouvé');
    }
}
