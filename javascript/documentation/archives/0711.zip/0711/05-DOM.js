

// *** DOM : Document Object Model : version de notre HTML affichée par notre navigateur *** //

// la porte d'entrée du DOM est l'objet document


// *** Accéder aux éléments du DOM  *** //

// querySelector() utilise les sélecteurs CSS
// ne cible que le 1er élément correspondant à la requête

document.querySelector('h1'); // --> '<h1>WELCOME TO THE DOM</h1>'
document.querySelector('p'); // -->  '<p>Paragraphe N°1</p>'

// on peut stocker le résultat de la sélection dans une variable

let mainTitle = document.querySelector('h1');

// getElementByID() cible un élément via son ID

document.getElementById('mainTitle');  // -->  <h1 id="mainTitle">WELCOME TO THE DOM</h1>


// querySelectorAll() renvoie une liste d'éléments

document.querySelectorAll('p');  // --> NodeList(2) [p, p]



//  changer le texte d'un élément HTML

mainTitle.textContent = 'Nouveau titre créé en JavaScript';

// changer le contenu HTML d'un élément

document.querySelector('ul').innerHTML = `
    <li>item 1</li>
    <li>item 2</li>
    <li>item 3</li>`;


    
// *** EXERCICE *** //
    
const towns = ['Boulogne', 'Toronto', 'Madrid', 'Agadir', 'Djakarta'];

/*
    A l'intérieur du <ul> avec l'id="towns", intégrer chaque ville du tableau dans un <li>
*/


for (let town of towns) {
    document.getElementById('towns').innerHTML += `<li> ${town} </li>`
}


