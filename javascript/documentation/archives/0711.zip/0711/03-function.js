
// *** créer une fonction *** //

function sayHello() {
    console.log('Hello');
}


// *** utiliser une fonction (appeler une fonction) *** //

sayHello();
sayHello();
sayHello();
sayHello();


// NB: nommer les functions selon leur rôle
// createPassword()  - checkPassword()


// *** utiliser des paramètres *** //

// un paramètre est une variable dont la valeur sera donnée au moment d'utiliser la fonction

function sayHi(userName) {  // let userName;
    console.log('Hi ' + userName);
}

sayHi();  //  --> Hi undefined   
sayHi('Jon'); // --> Hi Jon   (userName = 'Jon')
sayHi('Suzy'); // --> Hi Suzy  (userName = 'Suzy')


// utiliser plusieurs paramètres

function addNumb(numb1, numb2) {  // let numb1;  let numb2;
    console.log( `${numb1} + ${numb2} = ${numb1 + numb2}` );
}

addNumb();  // undefined + undefined = NaN
addNumb(10, 20);   // numb1 = 10;  numb2 = 20;
addNumb(5, 4);     // numb1 = 5;  numb2 = 4; 


// récupérer tous les arguments passés à une fonction : Rest Parameter

function getParam(...params) {
    // un tableau est créé avec tous les arguments dedans
    console.log(params); 
}


getParam();
getParam(1, 2, 3);


// *** EXERCICE *** //

// Créer une fonction qui additionne tous les chiffres passés en paramètres et affiche la somme finale

function addAllNumbers(...numbs) {
    
    let sumOfNumbers = 0;

    for (let numb of numbs){
        sumOfNumbers += numb;  // sumOfNumbers = sumOfNumbers + numb
    }
    console.log(sumOfNumbers);
}

addAllNumbers(4, 8, 12, 50);


// *** UNE FONCTION PEUT RENVOYER (produire) UNE DONNEE *** //

function returnUserName(userName) {
    
    return userName;

    console.log(userName); // instruction ignorée puisque placée après le return
}

returnUserName('Jon Doe');

// on peut stocker dans une variable la donnée retournée par la fonction

let returnedData = returnUserName('Jon Doe');

// on peut utiliser directement la donnée produite par la fonction
function sayHiToUser(userName){
    return `Hi ${userName} ! Welcome back !`
}

// ici on injecte dans le h1 la chaîne de caractères produite par la fonction
document.querySelector('h1').textContent = sayHiToUser('Tom');


