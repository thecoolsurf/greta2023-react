
// *** RAPPEL DECLARATION VARIABLE  *** //

// let : variable dont le contenu peut-être modifié (on lui ré-assigne un contenu)

let userName = 'Jon';
userName = 'Mark';


// const : variable dont on ne peut pas ré-assigner un contenu

const PI = 3.14116;
// PI = 7;  // ⚠️ OPERATION INTERDITE



const fruits = ['🍌', '🍓', '🥝', '🍍', '🍒', '🍐'];

// fruits = ['🍌', '🍓'];  // ⚠️ OPERATION INTERDITE

// mais il est possible de modifier le contenu en utilisant des méthodes spécifiques   




