// console.log(myVariable);  // ⚠️ ON NE PEUT PAS UTILISER UNE VARIABLE AVANT SA CREATION

let myVariable = 'xxx'


// AUTRE MANIERE DE CREER UNE FONCTION (en la stockant dans une variable) 

// sayHello(); // ⚠️ ON NE PEUT PAS UTILISER UNE VARIABLE AVANT SA CREATION

const sayHello = function() {
    console.log('Hello');
}


// en créant les fonctions de cette manière, on peut les appeler avant de les créer

sayHi(); 

function sayHi() {
    console.log('Hi');
}



// syntaxe ES6 d'une fonction : fonction fléchée

const helloWorld = () => {
    console.log('Hello')
    console.log('Hello World');
}

// si une seule instruction, on peut enlever les accolades pour tout mettre surune seule ligne

const justHello = () => console.log('Hello');


// si on a un seul paramètre, on peut enlever les parenthèses

const sayHiToUser = userName => console.log(`Hi ${userName}`);


// si la seule instruction est un return

const multNumb = (numb1, numb2) => {
    return numb1 * numb2;
}

const addNumb = (numb1, numb2) => numb1 + numb2;


const sayHelloToUser = userName => `Hi ${userName}`;



