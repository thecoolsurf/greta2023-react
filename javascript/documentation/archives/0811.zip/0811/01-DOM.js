
// *** accéder aux éléments du DOM *** // 


// querySelector() cible le premier élément correspondant au sélecteur CSS utilisé

document.querySelector('h1');  // --> le <h1>

document.querySelector('p');   // --> le 1er <p>

document.querySelector('p:last-of-type'); // --> le dernier <p> 


// si on cible un élément inexistant, ou si on cible mal un élément existant --> null

document.querySelector('a');  // --> null


// getElementById() cible l'élément selon selon id

document.getElementById('mainTitle'); // --> élément avec l'id mainTitle 


// querySelectorAll() récupère tous les éléments correspondant à la sélection

document.querySelectorAll('p');  // --> tous les <p>

document.querySelectorAll('p.para');  // --> tous les <p> avec la classe para


// textContent : modifier / ajouter / créer le texte d'un élément

document.querySelector('h1').textContent = 'NOUVEAU CONTENU';


// innerHTML : modifier / ajouter / créer le contenu HTML d'un élément

document.querySelector('p').innerHTML = `Lorem ipsum <strong>dolor</strong> sit amet.`




// ** Créer des éléments HTML ** //

let myHeader = document.createElement('header');
myHeader.textContent = '<header> ajouté avec before()';

let myFooter = document.createElement('footer');
myFooter.textContent = '<footer> ajouté avec after()';


let firstH3 = document.createElement('h3');
firstH3.textContent = '<h3> ajouté avec prepend()';

let lastH3 = document.createElement('h3');
lastH3.textContent = '<h3> ajouté avec append()'


// *** Ajouter des éléments HTML au DOM  *** //

// before() place l'élément <header> avant le <main>
document.querySelector('main').before(myHeader);

// after() place l'élément <footer> après le <main>
document.querySelector('main').after(myFooter);


// prepend() ajoute un <h3> au début du <main>
// (on peut ajouter plusieurs éléments à la suite)
document.querySelector('main').prepend(firstH3);
// append() ajoute un <h3> à la fin du <main>

// (on peut ajouter plusieurs éléments à la suite)
document.querySelector('main').append(lastH3);



// *** Ajouter des éléments avec des attributs *** //

// ajouter une image

let image = document.createElement('img');

image.src = "https://picsum.photos/400/200?grayscale";
image.alt = "image random noir et blanc";
image.title = "https://picsum.photos";

document.querySelector('h1').after(image);

// ajouter un lien

let lien = document.createElement('a');

lien.textContent = 'plus d\' infos sur le DOM';

lien.href = "https://www.w3schools.com/jsref/dom_obj_document.asp";
lien.title = 'doc W3Schools';
lien.target = '_blank';

document.querySelector('img').after(lien);


//  supprimer un attribut
lien.removeAttribute('title');


// enlever ou mettre un attribut
image.toggleAttribute('hidden'); // ajoute l'attribut
image.toggleAttribute('hidden'); // enlève l'attribut



// *** Changer le style d'un élément *** //

// toutes les propriétés CSS sont disponibles sous format camelCase

document.getElementById('mainTitle').style.backgroundColor = "rgb(37,37,37)";
document.getElementById('mainTitle').style.color = "#f5f5f5";
document.getElementById('mainTitle').style.padding = "2rem";
document.getElementById('mainTitle').style.textAlign = "center";


// Bonne pratique : créer une classe en CSS et l'ajouter en JavaScript

// classList : add | remove | toggle

document.querySelector('.quizz p:first-child').classList.add('goodAnswer');
document.querySelector('.quizz p:last-child').classList.add('badAnswer');