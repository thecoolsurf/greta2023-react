
// vider le contenu HTML existant
document.querySelector('main').innerHTML = '';

let userNumb = prompt('combien d\'articles voulez-vous ?');

// création de la fonction 
function createArticle(numb) {
    
    for (let i = 0; i < numb; i++) {
        
        let article = document.createElement('article');
        article.classList.add('blogArticle');
        
        article.innerHTML = `
        <h2>Article N°${i + 1}</h2>
        <img src="https://picsum.photos/400/200?blur&random=${i}" alt="image random noir et blanc">
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reiciendis quae quasi nostrum dolor sapiente voluptatum mollitia eum facere sunt ex magni, rerum voluptatem quas. Quo quaerat obcaecati quisquam ipsum repudiandae.</p>
        <a href="https://picsum.photos/400/200?blur&random=${i}">voir l'image en grand</a>`
        
        document.querySelector('main').append(article);
    }
}

// appel de la fonction
createArticle(userNumb);





