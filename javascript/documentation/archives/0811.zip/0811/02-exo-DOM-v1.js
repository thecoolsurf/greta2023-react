
// vider le contenu HTML existant
document.querySelector('main').innerHTML = '';


/*

prompt('combien d\'articles voulez-vous ?');

si réponse récupérée = 3  --> créer et afficher dans la page 3 articles

1 article = 1 container contenant : 
  - un titre
  - une image 
  - un paragraphe
  - un lien
  
  - ajouter du style à l'article avec une/des classes CSS
  
  - inclure dynamiquement dans le titre de chaque article un numéro  (article N°1...)
*/
 
 
let numb = prompt('combien d\'articles voulez-vous ?');

for (let i=0; i<numb; i++) {

    let article = document.createElement('article');
    article.classList.add('blogArticle');
    
    let title = document.createElement('h2');
    title.textContent = 'Article N°';
    
    let image = document.createElement('img');
    image.src = 'https://picsum.photos/400/200?grayscale';
    image.alt = 'image random noir et blanc';
    image.target = '_blank';
    
    let para = document.createElement('p');
    para.textContent = 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reiciendis quae quasi nostrum dolor sapiente voluptatum mollitia eum facere sunt ex magni, rerum voluptatem quas. Quo quaerat obcaecati quisquam ipsum repudiandae.';
    
    let lien = document.createElement('a');
    lien.href = 'https://picsum.photos/400/200?grayscale';
    lien.textContent = 'voir l\'image en grand';
    
    article.append(title, image, para, lien);
    
    document.querySelector('main').append(article);
}