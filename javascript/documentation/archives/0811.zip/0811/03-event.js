

// le click sur le <h1> déclenche la fonction anonyme donnée en 2ème paramètre

document.querySelector('h1').addEventListener('click', function(){
    console.log('click');
})

// une fonction fléchée est souvent utilisée dans un eventListener

document.querySelector('h1').addEventListener('click', () => console.log('click'))


function createAccount() {
    console.log('création du compte utilisateur')
}

/*
pour exécuter une fonction au moment du click, il ne faut pas mettre de parenthèses après le nom de la fonction (sinon elle sera exécutée automatiquement)
*/

document.getElementById('createAccountBtn').addEventListener('click', createAccount)
