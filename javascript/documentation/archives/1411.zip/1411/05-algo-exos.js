

// *** Index Of *** //

/*
- Créer une fonction qui prend 2 paramètres : un mot et une lettre à trouver dans le mot
- Si la lettre est présente, la fonction renvoie l’index de la lettre dans le mot
(index de la 1ère lettre trouvée si la lettre est présente plusieurs fois)
- Si la lettre n’est pas présente, la fonctionne renvoie -1
- Ne pas utiliser la fonction native indexOf()
*/


// VERSION 1 //
function findIndex(word, letter) {

    for (let i=0; i < word.length; i++) {
       if (word[i] === letter) {
            return i;
       }
       
       if (i === word.length - 1) {
            return -1;
       }
       
    }
}

findIndex('react', 'a');
findIndex('html', 'z');

// VERSION 2 // 

const findIndexOf = (word, letter) => {
    for (let i=0; i < word.length; i++) {
        if (word[i] === letter) return i;   
    }
    return -1;
}



// *** Check final "s" *** //

/*
- La fonction doit vérifier si le mot se termine par la lettre “s”
- La fonction doit renvoyer un booléen (true si le mot se termine par un "s" et false dans le
cas contraire)
*/

// VERSION 1 //
function checkfinalS(word) {
    // if (word[word.length-1] === 's') {
    //     return true
    // }
    // else {
    //     return false
    // }
    
    return word[word.length-1] === 's';
}

// VERSION 2 //
const checkfinalS2 = word => word.slice(-1) === 's';




// *** Capitalize Words *** //

/*
- Créer une fonction qui prend une phrase en paramètre.
- Cette phrase comporte plein de majuscules placées un peu n'importe où.
- Cette fonction doit renvoyer cette même phrase avec une majuscule à la première lettre
de chaque mot uniquement
*/

// VERSION 1 //
function capitalizeWord(sentence) {
    
    sentence = sentence.toLowerCase().split(' ');
    // --> ['des', 'majuscules', 'partout']

    let tab = [];

    for (let word of sentence) {
        tab.push(word[0].toUpperCase() + word.slice(1))
        // pour chaque mot, on colle la première lettre en majuscule et le reste du mot
        // et on ajoute le mot au tableau
    }

    // on retransforme le tableau en chaîne de caractères
    return tab.join(' ')

}

capitalizeWord('dEs MaJuSculES ParTouT')


// VERSION 2 //

function capitalizeIt(sentence) {

    sentence = sentence.toLowerCase().split(' ');
    let newSentence = '';

    for (let word of sentence) {
        newSentence += `${word[0].toUpperCase()}${word.slice(1)} `;
    }

    return newSentence.trim();
}

capitalizeIt('dEs MaJuSculES ParTouT')



// *** Check Palindrome *** //

/*
- Créer une fonction qui prend un mot en paramètre.
- La fonction doit vérifier si ce mot est ou non un palindrome
(mot qui peut être lu dans les deux sens. Exemple : kayak)
- La fonction renvoie un booléen (true si c'est un palindrome, false si ce n'est pas un
palindrome)
*/


function checkPalindrome(word){

    let reversed = [];

    for (let i=word.length-1; i >=0; i--) {
        reversed.push(word[i]);
    }

    for (let letter of word) {
        reversed.unshift(letter);
    }

    return reversed.join('') === word;

    // return word.split('').reverse().join('') === word

}

checkPalindrome('maison')


// *** Find Max *** //

/* 
- Créer une fonction prenant des nombres en paramètres
- Cette fonction doit retourner le plus grand des nombres
*/


function findMax(...numbers) {

    let higherNumb = numbers[0];

    for (let numb of numbers) {
        if (numb > higherNumb) {
            higherNumb = numb;
        }
    }

    return higherNumb;

}

findMax(12, 8, 4)


// *** Fizz Buzz *** //

/*
- Créer une boucle de 0 à 50 inclus
- Afficher chaque numéro dans la console
- Si le numéro est multiple de 3 : on affiche "fizz" au lieu du numéro
- Si le numéro est multiple de 5 : on affiche "buzz" au lieu du numéro
- Si le numéro est multiple de 3 et 5 : on affiche "fizzbuzz" au lieu du numéro
*/