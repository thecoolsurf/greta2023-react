/*
- Créer une fonction qui prend 2 paramètres : un tableau (de strings ou numbers) et un
nombre
- La fonction doit renvoyer un tableau dans lequel toutes les valeurs du tableau initial
sont réparties dans des tableaux dont la longueur est celle indiquée en deuxième
paramètre
- chunkThis( [1, 2, 3, 4, 5, 6, 7], 2 ) doit retourner [ [ 1, 2 ], [ 3, 4 ], [ 5, 6 ], [ 7 ] ]

*/

// *** VERSION 1 *** //

function chunkThis(arr, size) {

    let arr0 = [];

    // pas besoin de décrémenter puisque le tableau raccourcit avec chaque tour avec splice() //
    // la longueur du tableau passée en paramètre finit par être 0
     for(let i=0; i<arr.length;){   
        arr0.push(arr.splice(i, size));     	
    }
    return arr0;	
}    
      

// *** VERSION 2 *** //
  
function chunkThis2(arr, size) {

    let arr0 = [];
    while(arr.length>0){   
        arr0.push(arr.splice(0, size));
        }
        return arr0;
    
} 
  

chunkThis([0, 1, 2, 3, 4, 5, 6, 7, 8], 2);
// --> [ [ 0, 1 ], [ 2, 3 ], [ 4, 5 ], [ 6, 7 ], [ 8 ] ]