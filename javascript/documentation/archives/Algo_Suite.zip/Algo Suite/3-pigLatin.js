/*

- Créer une fonction qui prend un ou plusieurs mots en paramètre
- La fonction doit renvoyer ce mot transformé en mot d'argot "Pig Latin"
- Quand un mot commence par un voyelle on ajoute à la fin "- way " :   
    orange  →  orange-way
- Quand un mot commence par des consonnes, elles sont enlevées et ajoutées à la fin suivie de "ay" :  
    grape → ape-gray

*/

function translatePigLatin(str) {

    let regex1 = /(^[^aeiou]+)/;   // cible les mots ne commençant pas par une voyelle //
    let regex2 = /([^aeiou]+)(\w+)/;  // cible les mots commençant par une voyelle //
    

  
    // si le mot ne commence pas par une voyelle, on lui rajoute juste 'way' à la fin // 
    if(str.match(regex1) === null){   
      return str+'way'
    }
  
    else { 
      return str.replace(regex2, '$2$1ay') /* remplace les lettres correspondant  */
    }
    
  }
  
