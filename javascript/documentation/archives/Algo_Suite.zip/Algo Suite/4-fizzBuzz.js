/*
- Créer une boucle de 0 à 50 inclus
- Afficher chaque numéro dans la console
- Si le numéro est multiple de 3 : on affiche "fizz" au lieu du numéro
- Si le numéro est multiple de 5 : on affiche "buzz" au lieu du numéro
- Si le numéro est multiple de 3 et 5 : on affiche "fizzbuzz" au lieu du numéro 

*/


// --- VERSION 1 --- //

for (let i = 0; i <= 50; i++) {

    if (i % 3 === 0 && i % 5 === 0) {
        console.log('fizzbuzz');
    }
    else if (i % 3 === 0) {
        console.log('fizz');
    }
    else if (i % 5 === 0) {
        console.log('buzz');
    }
    else {
        console.log(i);
    }
}

// --- VERSION 2 --- //    

for (let i = 1; i <= 50; i++) {

    let magicWord = '';

    if (i % 3 == 0) {
        magicWord  += 'Fizz';
    }
    if (i % 5 == 0) {
        magicWord += 'Buzz';
    }
    if (!magicWord) {   // si magicWord est vide --> false
        magicWord = i;
    }

    console.log(magicWord);
}

// --- VERSION 3 --- //

for (let i=1; i<=50; i++) {

    	
    // variable créée à chaque tour de boucle (undefined donc false au début)
    let output;

    if (i%3 == 0 && i%5 == 0) {
        output = "FizzBuzz"
    } else if (i%3 == 0) {
        output = "Fizz"
    } else if (i%5 == 0) {
        output = "Buzz"
    } 

    console.log(output || i);
}

/*
if output with message === true  --> log output
if output empty === false  --> log i
*/


// --- 🔥 MIX V2 + V3 🔥 --- //   

for (let i = 0; i <= 50; i++) {

    let msg = ''  // --> false

    if (!(i % 3)) {  // si 0 --> false  --> !false --> true ✨✨
        msg += 'Fizz';
    }
    if (!(i % 5)) {
        msg += 'Buzz';
    }

    console.log(msg || i);
}


// --- VERSION 4 - ternary 😖 --- //

for (let i = 0; i <= 50; i++) {

    i%3 == 0 && i%5 == 0 ? console.log(`fizzBuzz`) : 
    i%3 == 0 ? console.log(`Fizz`) :
    i%5 == 0 ? console.log(`Buzz`):
    console.log(i);

}

// ---- VERSION 5 🚀 ✨ 🤐 --- //

for(var i=1;i<100;i++){
    console.log( ( (['Fizz'][i%3] || '') + (['Buzz'][i%5] || '') ) || i )
 } 

/*

['Fizz'] et ['Buzz'] sont des tableaux qui ne contiennent qu'un élément 

[i%3] et [i%5] vont donner :
- soit [0] qui correspond donc à 'Fizz' ou 'Buzz'
- soit un index qui correspond à rien et vaut donc undefined

undefined || '' --> renvoie ''

A la fin :

'Fizz' || i  --> renvoie 'Fizz'
'Buzz' || i  --> renvoie 'Buzz'
'FizzBuzz' || i  --> renvoie 'FizzBuzz'
'' || i -->  renvoie i

*/