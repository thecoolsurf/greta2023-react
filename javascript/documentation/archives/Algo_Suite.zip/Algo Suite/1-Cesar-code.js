/*

- Créer une fonction qui décode une phrase selon le Code de César

    - Ce code décale chaque caractère de 13 places dans l'alphabet
    - Utiliser cette fonction pour décrypter les codes suivants :
      - BCRAPYNFFEBBZF
      - URYYB JBEYQ
      - PRPV RFG ZBA PBQR FRPERG 

*/

function crackCesarCode(str) {
    return str.split("") // transforme la phrase en tableau de mots
        .map((letter) => {
            
            let charCode = letter.charCodeAt(); // récupère unicode de la lettre
            // 77 : milieu de l'alphabet 

            //   if (charCode <= 77) {
            //     return String.fromCharCode(charCode + 13); 
            //   } else {
            //     return String.fromCharCode(charCode - 13); 
            //   }

            return charCode <= 77 ? String.fromCharCode(charCode + 13) : String.fromCharCode(charCode - 13);

        })
        .join("")
        .replace(/[-]/g, " "); /* remplace les espace par des tirets ( l'espace (32) est transformé en tiret (45) ) */
}

crackCesarCode("BCRAPYNFFEBBZF");  // --> OPENCLASSROOMS
crackCesarCode("URYYB JBEYQ");  // --> HELLO WORLD
crackCesarCode("PRPV RFG ZBA PBQR FRPERG"); // --> CECI EST MON CODE SECRET