

/*
la méthode addEventListener() prend 2 arguments :
    - le nom de l'événement
    - la fonction à exécuter quand l'événement se produit
*/

document.querySelector('button').addEventListener('click', function(event) {
    console.log('bouton cliqué');
    console.log(event.target);
    event.target.textContent = 'cliqué';
})

