
// *** EXO RGB *** //

/*

- capter la saisie de chacun des inputs range
- changer selon la saisie le contenu du paragraphe 'rgb(0,0,0)'
- appliquer ce code couleur au body

*/


let inputs = document.querySelectorAll('input');

inputs.forEach(item => {
    
    item.addEventListener('input', function() {
    
        let rgbCode = `rgb(${redColor.value}, ${greenColor.value}, ${blueColor.value})`;

        document.querySelector('.result').textContent = rgbCode;
        document.body.style.backgroundColor = rgbCode;
    })
})

