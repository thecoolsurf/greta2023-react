

// l'événement input permet de capter la saisie dans un champ de formulaire

document.getElementById('pseudoInput').addEventListener('input', function(event){

    // event.target.value permet de récupérer ce qui est saisi dans un input
    console.log(event.target.value);
})

// document.getElementById('passwordInput').addEventListener('input', function(event){
//     console.log(event.target.value);
// })

// document.getElementById('colorInput').addEventListener('input', function(event){
//     console.log(event.target.value);
// })

// récupérer tous les inputs
let inputs = document.querySelectorAll('input');

// attacher un addEventListener à chaque input avec la boucle for of
for (let input of inputs) {
    input.addEventListener('input', function(event){
        console.log(event.target.value);
    })
}


// *** forEach() est souvent utiliser pour boucler les éléments du DOM *** //

/* 
- cette boucle prend une fonction anonyme en paramètre (callback)
- le paramètre de cette fonction anonyme représente chacun des éléments de la liste
- par convention, ce paramètre est appelé item

*/

inputs.forEach(item => {
    // console.log(item);
    item.addEventListener('input', function(event) {
        console.log(event.target.value);
    })
})

// EXEMPLE : dès qu'une saisie est faite dans un des inputs, la fonction myFunction est exécutée

// inputs.forEach(item => item.addEventListener('input', myFunction))


// ***  REAGIR A L'ENVOI DU FORMULAIRE *** //

// Méthode 1
document.querySelector('button[type="submit"]').addEventListener('click', function(event){
    event.preventDefault(); // empêche la page de se recharger
    console.log('Evénement click');
})


// Méthode 2
document.querySelector('form').addEventListener('submit', function(event){
    event.preventDefault();
    console.log('Evénement submit');
    console.log(pseudoInput.value);
})


// ***  REAGIR AU RESET DES DONNEES  *** /

document.querySelector('form').addEventListener('reset', function(){
    console.log('données effacées');
})