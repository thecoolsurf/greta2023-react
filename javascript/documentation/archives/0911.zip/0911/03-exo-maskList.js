

// ***  EXO MASK LIST  *** //


/*

- Quand on clique sur le bouton, le texte devient 'Display List' et la liste disparaît
- Quand on reclique sur le bouton, le texte redevient 'Mask List' et la liste réapparaît

*/

document.querySelector('button').addEventListener('click', function(event){

    // faire disparaître la liste
    // document.querySelector('ul').style.display = 'none';
    // document.querySelector('ul').toggleAttribute('hidden');
    // document.querySelector('ul').remove();
    // document.querySelector('ul').innerHTML = '';
    // document.querySelector('ul').style.marginLeft = '-2000px'
    // document.querySelector('ul').style.opacity = 0;

    document.querySelector('ul').classList.toggle('noOpacity');

    if (event.target.textContent === 'Mask List') {
        event.target.textContent = 'Display List';
    }
    else {
        event.target.textContent = 'Mask List';
    }


})