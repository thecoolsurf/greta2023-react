

// ***  EXO DARK MODE  ***  //


/*

- au click sur l'image :
    - on ajoute une classe darkMode créée en CSS
    - le contenu de l'image change pour afficher le soleil à la place de la lune

- pouvoir identifier si le darkMode est activé ou non 

- au click sur l'image, si le darkMode est activé :
    - on désactive le darkMode
    - on remet la lune à la place du soleil

*/

// on crée une variable indiquant l'état du darkMode
let isDarkMode = false;

document.getElementById('darkModeBtn').addEventListener('click', function(event){

    // on ajoute ou enlève la classe 'darkMode'
    document.body.classList.toggle('darkMode');

    // on inverse le contenu du booléen isDarkMode
    isDarkMode = !isDarkMode;

    // selon l'état du darkMode, on change la source de l'image
    if (isDarkMode) {
        event.target.src = 'sun.png';
    }
    else {
        event.target.src = 'moon.png'; 
    }

    // event.target.src = isDarkMode ? 'sun.png' : 'moon.png';    
})