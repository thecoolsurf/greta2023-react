function movePixel(color, index) {

    // création de la div
    let pixel = document.createElement('div');

    // ajout du style à la div
    pixel.classList.add('mouseMove');
    pixel.style.backgroundColor = color;

    // ajout coordonnées à la div
    pixel.style.top = event.clientY + 'px';
    pixel.style.left = event.clientX + 'px';

    pixel.style.zIndex = index

    // ajout de la div au DOM
    document.body.prepend(pixel);
}


window.onmousemove = () => movePixel('red');


window.addEventListener('click', function(){
    window.onmousemove = () => movePixel('blue', 1);
})