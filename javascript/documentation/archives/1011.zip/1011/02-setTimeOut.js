
console.log('UN');

setTimeout(function(){
    console.log('DEUX')
}, 3000)

console.log('TROIS');
console.log('QUATRE');

