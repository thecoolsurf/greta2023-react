
// variables pour stocker les choix
let userChoice;
let computerChoice;

// choix dans lesquels piocher au hasard pour le computer
let choices = ['rock', 'paper', 'scissors'];

// variables pour le résultat
let resultMessage;
let colorMessage;



// *** CHOIX UTILISATEUR *** //

// récupérer les images cliquables par l'utilisateur
let userPics = document.querySelectorAll('.userPics img');

// réagir au click utilisateur
userPics.forEach(item => {
    item.addEventListener('click', function(event){
        
        // stocker le choix de l'utilisateur
        userChoice = event.target.alt;

        // afficher le choix de l'utilisateur
        event.target.classList.add('picked');
        document.querySelector('.userPics').classList.add('onePicked');


        // *** CHOIX COMPUTER *** //
        
        // choix du computer déclenché 2 secondes après le click utilisateur
        setTimeout(() => {
                    
            // générer un nombre aléatoire entre 0, 1 et 2
            let randomNumb = Math.floor(Math.random() * 3);
            
            // stocker le choix correspondant au nombre aléatoire dans le tableau de choix
            computerChoice = choices[randomNumb];
            
            // afficher le choix du computeur
            document.querySelector(`.computerPics img[alt="${computerChoice}"]`).classList.add('randomed');
            document.querySelector('.computerPics').classList.add('onePicked');
            
            
            // *** COMPARER LES CHOIX *** //
            
            // lister les cas où l'utilisateur gagne 
            if ((userChoice === 'rock' && computerChoice === 'scissors') || 
            (userChoice === 'paper' && computerChoice === 'rock') || 
            (userChoice === 'scissors' && computerChoice === 'paper')) {
                
                resultMessage = 'GAGNE';
                colorMessage = 'green';
            }
            else if (userChoice === computerChoice) {
                resultMessage = 'EGALITE';
                colorMessage = 'white'
            }
            else {
                resultMessage = 'PERDU';
                colorMessage = 'red'
            }



            // afficher le réultat 2 secondes après la fin des comparaisons
            
            setTimeout(() => {
            document.getElementById('result').textContent = resultMessage;
            
            document.querySelector('.gameBoard').style.opacity = '0.2';
            document.getElementById('result').style.border = `4px solid ${colorMessage}`;
            document.getElementById('result').style.padding = `3rem`;
            document.getElementById('result').style.color = colorMessage;
            
            },2000)



        },2000)

        
    })
})


    