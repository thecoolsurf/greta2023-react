

// on capte le déplacement de la souris sur toute la page 

window.addEventListener('mousemove', function(event){
    console.log(event.clientX);
    console.log(event.clientY);
})


/*
A chaque déplacement de la souris :
- créer une div
- l'ajouter au DOM
- lui donner les coordonnées récupérées de l'evénement mousemove
*/


window.addEventListener('mousemove', function(event){

    // création de la div
    let pixel = document.createElement('div');

    // ajout du style à la div
    pixel.classList.add('mouseMove');

    // ajout coordonnées à la div
    pixel.style.top = event.clientY + 'px';
    pixel.style.left = event.clientX + 'px';

    // ajout de la div au DOM
    document.body.prepend(pixel);

})

