

// opérateurs arithmétiques raccourcis

let userScore = 12;

// ajouter un bonus de 10

userScore = userScore + 10;   // --> 22

userScore += 10;  // --> 32

userScore -= 5;  // --> 27 

userScore *= 2;  //  --> 54

userScore /= 3;  // --> 18


// incrémenter de 1 

userScore++;  // --> 19


// décrémenter de 1

userScore--;  // --> 18


// concaténation rzaccourcie

let userMessage = 'jonDoe';

userMessage += ' is the winner';





