

// *** OPERATEURS DE COMPARAISON *** //

//  < <= > >=  == ===  != !==



// *** OPERATEURS LOGIQUES *** //

/*
OR :  || (alt gr + 6) 

permet de vérifier qu'AU MOINS UNE condition soit vraie
si une seule des vérifications renvoie TRUE alors le résultat final est TRUE
*/

let userSatisfaction = '😠' ;

// '😃' - '😁' - '😠' - '😢'

// est-ce que la variable userSatisfaction contient '😃' ou  '😁'

userSatisfaction === '😃' ||  userSatisfaction === '😁';


/*
AND : && (alt gr + 1)
permet de vérifier que TOUTES les conditions soient vraies
si une seule renvoie FALSE alors le résultat final est FALSE
*/

let newsLetterChecked
let premiumAccessChecked;


// est-ce que la variable newsLetterChecked vaut true 
// ET est-ce que la variable premiumAccessChecked vaut true 

newsLetterChecked === true && premiumAccessChecked === true; 







