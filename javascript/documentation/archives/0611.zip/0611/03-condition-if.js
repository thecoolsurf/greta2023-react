
/*
- si ce qui est entre les parenthèses du if vaut TRUE :
  les instructions entres les accolades qui suivent seront exécutées
- si cela vaut FALSE :
  ce sont les instructions entre les accolades qui suivent le else qui seront exécutées
*/

let userAge = 10;
let message;

if (userAge < 18) {
    message = 'vous ne pouvez pas rentrer';
}

// le else n'est pas obligatoire
else {
    message = 'vous pouvez rentrer';
}

console.log(message);
console.log('suite du script');


// condition ternaire (syntaxe ES6)

userAge < 18 ? message = 'vous ne pouvez pas rentrer' : message = 'vous pouvez rentrer';

message = userAge < 18 ? 'vous ne pouvez pas rentrer' : 'vous pouvez rentrer';

