

// la fonction prompt() permet de poser une question et de récupérer la réponse
// on peut stocker la réponse dans une variable
// si la personne n'écrit aucun nom, la réponse sera "" (string vide)
// si la personne clique sur Annuler, la réponse sera null

/*
- si la personne écrit 'Jon' et clique sur OK
    --> mettre dans la variable message 'Bonjour Jon'

- si la personne écrit rien et clique sur OK 
    ou si la personne clique sur Annuler
    --> mettre dans la variable message 'Merci de saisir un prénom' 
*/

let userName = prompt('Quel est votre nom');
let message;

// VERSION 1 //

if (userName === "" || userName === null) {
    message = 'Merci de saisir un prénom';
}
else {
    // message = 'Bonjour ' + userName;
    message = `Bonjour ${userName}`;
}


// VERSION 2 (prendre en compte les valeurs falsy)

if (userName) {
    message = `Bonjour ${userName}`;
}
else {
    message = 'Merci de saisir un prénom'; 
}


// VERSION 3  (utiliser la condition ternaire)

message = userName ? `Bonjour ${userName}`: 'Merci de saisir un prénom';  


console.log(message);