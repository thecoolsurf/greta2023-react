/*

tous les valeurs valent TRUE, excepté certaines valeurs qui valent FALSE

valeurs falsy (qui valent FALSE): 

- false
- le chiffre 0 
- chaîne de caractères vide "" 
- null
- undefined
- NaN - Not a Number (mathématiquement pas possible)

*/