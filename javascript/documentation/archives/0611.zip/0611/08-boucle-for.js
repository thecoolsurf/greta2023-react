

for (let i=0; i <=10; i++) {
    console.log(i);
}


// *** Parcourir un tableau *** //

let fruits = ['🍌', '🍓', '🥝', '🍍'];

// connaître le nombre d'éléments d'un tableau
fruits.length;  // --> 4

// accéder à un élément du tableau
fruits[0];  // --> '🍌'
fruits[3];  // --> '🍍'


for (let i=0; i < fruits.length; i++) {
    console.log(fruits[i]);
}



// *** BOUCLE FOR OF (spécifique aux tableaux) *** //

for (let fruit of fruits) {
    // la variable fruit prend comme valeur chacun des éléments du tableau à chaque tour de boucle
    console.log(fruit);
}


