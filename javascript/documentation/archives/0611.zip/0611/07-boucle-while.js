

// *** BOUCLE WHILE *** //

/* 
tant que la condition entre parenthèses vaut TRUE, on exécute les instructions entre accolades
*/

let count = 0;

while (count < 5) {
    console.log (count);
    count++; // on ajoute 1 à la valeur de count 
}

let userName = prompt('Donnez-moi votre nom')

// tant que la personne ne donne pas un prénom on repose la question 

while (!userName) {
    userName = prompt('Veuillez saisir un prénom');
} 

console.log('Bonjour ' + userName);






