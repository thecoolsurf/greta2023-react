
let weather;
let message;

if (weather === '☀️') {
    message = 'il y a du soleil'
}
else if (weather === '☁️') {
    message = 'il y a des nuages'
}
else if (weather === '⛈️') {
    message = 'il pleut'
}
else if (weather === '❄️') {
    message = 'il neige'
}
else {
    message = "temps inconnu"
}


switch (weather) {
    case '☀️' : message = 'il y a du soleil';
        break;
    case '☁️' : message = 'il y a des nuages';
        break;
    case '⛈️' : message = 'il pleut';
        break;
    case '❄️' : message = 'il neige';
        break;
    default : message = "temps inconnu"
}



// ppur utiliser switch avec des comparaisons, il faut comparer chacun des cases à true

let userAge = 15;

switch (true) {
    case userAge < 16 : console.log('en-dessous de 16 ');
        break;
    case userAge <= 18 : console.log('entre 16 et 18');
        break;
    default : console.log('au-dessus de 18');
}