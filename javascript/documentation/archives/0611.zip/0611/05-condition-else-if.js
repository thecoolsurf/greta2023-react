

let userAge = 15;

/*
- en-dessous de 16 
- entre 16 et 18
- au-dessus de 18
*/

if (userAge < 16) {
    console.log('en-dessous de 16 ');
}
else if (userAge <= 18) {
    console.log('entre 16 et 18');
}
else {
    console.log('au-dessus de 18');
}

console.log('suite du script');